OPen file
