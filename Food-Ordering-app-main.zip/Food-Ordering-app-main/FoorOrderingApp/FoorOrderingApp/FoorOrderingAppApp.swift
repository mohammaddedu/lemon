//
//  FoorOrderingAppApp.swift
//  FoorOrderingApp
//
//  Created by Balumuri, Rajesh (Cognizant) on 22/05/24.
//

import SwiftUI

@main
struct FoorOrderingAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
